$(document).bind("mobileinit",  function() {
	$.mobile.keepNative = "input.boring";
});
